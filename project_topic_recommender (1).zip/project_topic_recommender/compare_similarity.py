"""
compare_similarity.py
Runs TF-IDF + cosine and BM25 on the same query and compares
(1) the rank of every repo and (2) Precision@k.

A repo counts as RELEVANT if it has at least one topic that the Knowledge
Graph matched directly from the student's interests (a simple, loose rule).

Usage:
    python compare_similarity.py "python, machine learning, nlp"
    python compare_similarity.py "python, machine learning, nlp" --sample
"""
import argparse

from recommender import (build_documents, build_knowledge_graph,
                         expand_with_knowledge_graph, load_data, recommend)


def precision_at_k(ranked, relevant_topics, k):
    top = ranked.head(k)
    hits = sum(1 for t in top["topics"]
               if set(t.split(";")) & set(relevant_topics))
    return hits / k if k else 0.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("interests", help='e.g. "python, machine learning, nlp"')
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--top", type=int, default=10)
    args = parser.parse_args()

    df = build_documents(load_data(args.sample))
    G = build_knowledge_graph(df)
    interests = [i.strip() for i in args.interests.split(",") if i.strip()]
    matched, _ = expand_with_knowledge_graph(G, interests)

    cos, _, _ = recommend(df, G, interests, len(df), "cosine")
    bm, _, _ = recommend(df, G, interests, len(df), "bm25")
    cos_rank = {n: i + 1 for i, n in enumerate(cos["name"])}
    bm_rank = {n: i + 1 for i, n in enumerate(bm["name"])}

    print(f"{'Repo':<20}{'Cosine rank':>12}{'BM25 rank':>11}  Change")
    for name in cos["name"].head(args.top):
        c, b = cos_rank[name], bm_rank.get(name)
        change = "same" if c == b else (f"higher (+{c - b})" if b and b < c
                                        else f"lower ({c - b})" if b else "-")
        print(f"{name:<20}{c:>12}{str(b):>11}  {change}")

    print()
    for k in (5, 10):
        print(f"Precision@{k}:  cosine = {precision_at_k(cos, matched, k):.2f}"
              f"   bm25 = {precision_at_k(bm, matched, k):.2f}")


if __name__ == "__main__":
    main()
