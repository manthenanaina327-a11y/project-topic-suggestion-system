"""
recommender.py
AI-Powered Project Topic Suggestion System
Pipeline: student interests -> Knowledge Graph expansion -> similarity
(TF-IDF + cosine OR BM25) -> ranked Top-N project topics.

Usage:
    python recommender.py                       # asks for interests, uses BM25
    python recommender.py --method cosine       # TF-IDF + cosine baseline
    python recommender.py --sample              # use the 16-repo sample data
"""
import argparse
import math
import os
import re
import sqlite3
from collections import Counter

import networkx as nx
import pandas as pd
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DB_PATH = "data/github_repos.db"
CSV_PATH = "data/github_repos.csv"
SAMPLE_PATH = "data/sample_repos.csv"


# ---------------------------------------------------------------- 1. load data
def load_data(use_sample=False):
    """Load repos from SQLite (preferred), then CSV, then the sample file."""
    if use_sample:
        return pd.read_csv(SAMPLE_PATH).fillna("")
    if os.path.exists(DB_PATH):
        conn = sqlite3.connect(DB_PATH)
        df = pd.read_sql("SELECT * FROM repositories", conn)
        conn.close()
    elif os.path.exists(CSV_PATH):
        df = pd.read_csv(CSV_PATH)
    else:
        print("Full dataset not found - using sample data. "
              "Run fetch_github_data.py to download the full dataset.")
        df = pd.read_csv(SAMPLE_PATH)
    return df.fillna("")


# ------------------------------------------------------------- 2. preprocessing
def clean(text):
    """lowercase -> remove symbols -> remove stop words -> drop tiny words."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)          # '-' and '!' become spaces
    words = [w for w in text.split()
             if w not in ENGLISH_STOP_WORDS and len(w) > 2]
    return " ".join(words)


def build_documents(df):
    """One text document per repo: description + topics (twice) + language."""
    topics_text = df["topics"].str.replace(";", " ")
    docs = df["description"] + " " + topics_text + " " + topics_text \
        + " " + df["language"]
    df = df.copy()
    df["doc"] = docs.apply(clean)
    return df


# -------------------------------------------------------- 3. knowledge graph
def build_knowledge_graph(df):
    """Graph: repo -- topic, repo -- language."""
    G = nx.Graph()
    for _, row in df.iterrows():
        repo = "repo:" + row["name"]
        G.add_node(repo, kind="repo")
        for topic in filter(None, row["topics"].split(";")):
            G.add_node(topic, kind="topic")
            G.add_edge(repo, topic)
        if row["language"]:
            lang = "lang:" + row["language"]
            G.add_node(lang, kind="language")
            G.add_edge(repo, lang)
    return G


def expand_with_knowledge_graph(G, interests, max_added=8):
    """
    Match each interest to a topic node, then add topics that co-occur
    with it in the same repos. Returns (matched, added).
    """
    topic_nodes = {n for n, d in G.nodes(data=True) if d["kind"] == "topic"}
    matched = []
    for interest in interests:
        name = interest.strip().lower().replace(" ", "-")
        if name in topic_nodes and name not in matched:
            matched.append(name)

    counts = Counter()                       # how often each topic co-occurs
    for topic in matched:
        for repo in G.neighbors(topic):
            for other in G.neighbors(repo):
                if other in topic_nodes and other not in matched:
                    counts[other] += 1
    added = [t for t, _ in counts.most_common(max_added)]
    return matched, added


# ---------------------------------------------------------- 4. similarity
def cosine_scores(df, query):
    """TF-IDF vectors + cosine similarity (baseline)."""
    vectorizer = TfidfVectorizer(ngram_range=(1, 2))
    repo_matrix = vectorizer.fit_transform(df["doc"])
    query_vector = vectorizer.transform([query])
    return cosine_similarity(query_vector, repo_matrix).flatten()


def bm25_scores(df, query, k1=1.5, b=0.75):
    """BM25 ranking: IDF + term saturation (k1) + length normalization (b)."""
    docs = [d.split() for d in df["doc"]]
    n_docs = len(docs)
    avg_len = sum(len(d) for d in docs) / n_docs
    doc_freq = Counter(w for d in docs for w in set(d))   # docs containing word

    scores = []
    for words in docs:
        freq = Counter(words)
        score = 0.0
        for w in set(query.split()):
            if w not in freq:
                continue
            idf = math.log((n_docs - doc_freq[w] + 0.5) / (doc_freq[w] + 0.5) + 1)
            f = freq[w]
            score += idf * f * (k1 + 1) / (f + k1 * (1 - b + b * len(words) / avg_len))
        scores.append(score)

    scores = pd.Series(scores)
    return (scores / scores.max()).values if scores.max() > 0 else scores.values


# ----------------------------------------------------------- 5. recommend
def recommend(df, G, interests, top_n=10, method="bm25"):
    """Return (ranked DataFrame, matched topics, added topics)."""
    matched, added = expand_with_knowledge_graph(G, interests)
    expanded = " ".join(interests) + " " + " ".join(matched + added)
    query = clean(expanded)

    scores = bm25_scores(df, query) if method == "bm25" else cosine_scores(df, query)
    best = scores.argsort()[::-1][:top_n]
    result = df.iloc[best].copy()
    result["score"] = scores[best]
    return result[result["score"] > 0], matched, added


# ---------------------------------------------------------------- main
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--method", choices=["bm25", "cosine"], default="bm25")
    parser.add_argument("--top", type=int, default=10)
    parser.add_argument("--sample", action="store_true",
                        help="use the 16-repo sample dataset")
    args = parser.parse_args()

    df = build_documents(load_data(args.sample))
    G = build_knowledge_graph(df)

    text = input("Enter your interests/skills: ")
    interests = [i.strip() for i in text.split(",") if i.strip()]

    result, matched, added = recommend(df, G, interests, args.top, args.method)
    print("Knowledge Graph matched topics :", matched)
    print("Knowledge Graph added topics   :", added)
    print(f"\nTOP RECOMMENDED PROJECT TOPICS ({args.method.upper()})")
    for rank, (_, row) in enumerate(result.iterrows(), start=1):
        print(f"{rank}. {row['name']}  (score: {row['score']:.3f})")
        print(f"   Idea   : {row['description']}")
        print(f"   Topics : {row['topics'].replace(';', ', ')}")


if __name__ == "__main__":
    main()
