# Project Topic Suggestion System

Picking a project topic is harder than it sounds. Most students know what they're
interested in ("Python, NLP, maybe something with data") but have no idea what to
actually build. Scrolling through thousands of GitHub repos isn't much help either.

So I built a small tool that does the scrolling for you. You type in your interests,
and it suggests project ideas based on real GitHub repositories that people have
already built.

Made by Manthena Naina (B.Tech CSE, ICFAI Tech), guided by Dr. Sanjib Raul and
Dr. Srinivasarao Dhanikonda.

## How it works

Here's the flow in plain words:

1. **Get the data.** I pulled 1,500+ popular public repos from the GitHub Search API,
   covering 20 topics like machine learning, NLP, web, IoT and blockchain. Each repo
   has a name, description, topics, language and star count. Everything is stored in
   a SQLite database.
2. **Clean the text.** Lowercase everything, strip symbols, drop stop words and tiny
   words. Then the description, topics (counted twice, since they're the best
   signal) and language get merged into one block of text per repo.
3. **Expand your interests with a Knowledge Graph.** If you type `nlp`, the graph
   finds the topic `nlp` and then looks at what else shows up in the same repos, like
   `chatbot`, `sentiment-analysis` or `transformers`. That way you also see ideas you
   didn't think to type. The graph is built with networkx.
4. **Score every repo.** There are two options:
   - **BM25** (my proposed method). It gives more weight to rare words, stops
     repeated words from inflating the score, and doesn't favour long descriptions.
   - **TF-IDF + cosine similarity** (the baseline I compared against).
5. **Rank and return the top N.** Best matches first, with their scores.

## What's in the repo

| File | What it does |
|------|--------------|
| `fetch_github_data.py` | Downloads repos from GitHub and saves them as CSV and SQLite |
| `recommender.py` | The main program: cleaning, Knowledge Graph, both scoring methods, results |
| `compare_similarity.py` | Compares cosine vs BM25 rankings and Precision@k |
| `data/sample_repos.csv` | A tiny 16-repo dataset so you can try it without downloading anything |
| `requirements.txt` | Python packages needed |

## Getting started

```bash
pip install -r requirements.txt
```

### 1. Download the full dataset (optional)

```bash
python fetch_github_data.py
```

This takes a while because of GitHub's rate limits. If it keeps getting blocked, create
a free GitHub token and set it as the `GITHUB_TOKEN` environment variable.

### 2. Ask for suggestions

```bash
python recommender.py                    # uses BM25
python recommender.py --method cosine    # uses TF-IDF + cosine instead
python recommender.py --sample --top 5   # sample data, top 5 results
```

A run looks like this:

```
Enter your interests/skills: python, machine learning, nlp
Knowledge Graph matched topics : ['machine-learning', 'nlp']
Knowledge Graph added topics   : ['text-classification', 'sentiment-analysis', ...]

TOP RECOMMENDED PROJECT TOPICS (BM25)
1. d/sentiment  (score: 1.000)
   Idea   : Sentiment analysis tool for product reviews
```

### 3. Compare the two methods

```bash
python compare_similarity.py "python, machine learning, nlp" --sample
```

For this comparison I call a repo "relevant" if it shares at least one topic with the
ones matched directly from your interests. It's a loose rule, but it keeps things
simple.

## A fair warning about the results

The sample dataset only has 16 repos, so the rankings are just a demo. They're too
small to say whether BM25 or cosine is actually better. To get a real answer, run
`fetch_github_data.py` and compare both methods on the full dataset.

## Limitations

- It matches words, not meaning, so "car" and "automobile" look unrelated to it.
- It can only suggest what's already in the dataset.
- Results depend on how well people tagged their repos.
- The first download is slow because of GitHub's API limits.

## What I'd like to add next

- Sentence-BERT embeddings so it understands meaning
- A hand-built Knowledge Graph instead of one learned from co-occurring tags
- A simple web page using Streamlit or Flask
- Recall@k alongside Precision@k
- Filters for difficulty level and programming language

## Built with

Python, requests, pandas, SQLite, networkx, scikit-learn
