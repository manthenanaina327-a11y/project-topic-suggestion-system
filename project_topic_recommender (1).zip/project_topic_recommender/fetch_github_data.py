"""
fetch_github_data.py
Downloads the most-starred public repositories for 20 topics using the
GitHub Search API and saves them to data/github_repos.csv and
data/github_repos.db (SQLite).

Usage:
    python fetch_github_data.py
    (optional) set a token to avoid strict rate limits:
        export GITHUB_TOKEN=your_token_here      (Windows: set GITHUB_TOKEN=...)
"""
import os
import sqlite3
import time

import pandas as pd
import requests

TOPICS = [
    "machine-learning", "nlp", "computer-vision", "deep-learning",
    "data-science", "web", "iot", "blockchain", "cybersecurity",
    "chatbot", "recommender-system", "android", "game-development",
    "automation", "data-visualization", "api", "database",
    "cloud-computing", "robotics", "healthcare",
]
PER_TOPIC = 100          # GitHub allows up to 100 results per page
URL = "https://api.github.com/search/repositories"


def fetch_topic(topic, token=None):
    """Return a list of repo dictionaries for one topic."""
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    params = {"q": f"topic:{topic}", "sort": "stars", "order": "desc",
              "per_page": PER_TOPIC}
    response = requests.get(URL, headers=headers, params=params, timeout=30)
    response.raise_for_status()

    repos = []
    for item in response.json()["items"]:
        repos.append({
            "name": item["full_name"],
            "description": item["description"] or "",
            "topics": ";".join(item.get("topics", [])),
            "language": item["language"] or "",
            "stars": item["stargazers_count"],
        })
    return repos


def main():
    token = os.environ.get("GITHUB_TOKEN")
    all_repos = []
    for topic in TOPICS:
        print(f"Fetching topic: {topic}")
        try:
            all_repos.extend(fetch_topic(topic, token))
        except requests.RequestException as err:
            print(f"  skipped ({err})")
        time.sleep(2)    # be polite: avoid hitting the rate limit

    df = pd.DataFrame(all_repos).drop_duplicates(subset="name")
    df = df[df["description"].str.strip() != ""]    # need text to compare

    os.makedirs("data", exist_ok=True)
    df.to_csv("data/github_repos.csv", index=False)

    conn = sqlite3.connect("data/github_repos.db")
    df.to_sql("repositories", conn, if_exists="replace", index=False)
    conn.close()
    print(f"Saved {len(df)} unique repositories.")


if __name__ == "__main__":
    main()
